# Long-Term Memory
_Last updated: 2026-03-05_

## About Naps3158
- Handle: @naps3158
- Identity: Naps (you specifically told me "Im naps")
- Timezone: Asia/Manila
- Areas of interest: AI development, crypto trading, NBA betting
- Tech stack preferences: Python, AI/ML frameworks

## Key Projects
- NBA Oracle: Automated NBA monitoring system with betting analysis
- Alpha Scanner: Crypto meme coin detection system
- Agent memory architecture implementation
- Crypto Oracle: Automated crypto market analysis with quarter-hour updates

## Communication Preferences
- Prefers concise, bullet-point responses
- Appreciates proactive memory updates
- Values documentation and system architecture discussions

## Tech Setup
- Current OS: macOS (Darwin)
- Node.js environment for OpenClaw
- Multiple Telegram connections configured

## Learned Patterns
- Often asks about PowerPoint creation capabilities
- Interested in autonomous systems and memory architectures
- Active during various times (including late night/early morning)
- Has configured Crypto Oracle for automated quarter-hour updates with comprehensive TA analysis